# LibraryProject

This is a basic Django project created as part of the ALX Django Learn Lab.  
It includes the default setup for a new Django project.
