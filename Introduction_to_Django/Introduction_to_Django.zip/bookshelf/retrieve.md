retrieved = Book.objects.get(title="1984")
retrieved.title
retrieved.author
retrieved.publication_year
