retrieved.delete()
Book.objects.all() # Should return an empty queryset
