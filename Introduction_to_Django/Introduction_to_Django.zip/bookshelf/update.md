retrieved.title = "Nineteen Eighty-Four"
retrieved.save()
retrieved.title  # Confirm update
