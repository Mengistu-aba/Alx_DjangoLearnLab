# LibraryProject

This is the initial setup for a Django project as part of the ALX Introduction to Django lab.