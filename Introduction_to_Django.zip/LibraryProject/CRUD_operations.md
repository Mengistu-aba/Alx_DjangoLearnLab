# CRUD Operations

Includes create, retrieve, update, and delete operations for the Book model using Django shell.